from django.shortcuts import render
from django.http import JsonResponse
import json

def chatbot_view(request):
    return render(request, 'chatbot.html')

def send_message(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        user_message = data.get('message', '')
        
        # TODO: Implement actual chatbot logic
        bot_response = f"You said: {user_message}"
        
        return JsonResponse({
            'response': bot_response
        })