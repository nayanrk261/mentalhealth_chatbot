from django.urls import path
from . import views

urlpatterns = [
    path('', views.counseling_home, name='counseling_home'),
    path('resources/', views.resources, name='resources'),
]