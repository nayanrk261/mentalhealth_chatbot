from django.shortcuts import render
from django.contrib.auth.decorators import login_required

def counseling_home(request):
    return render(request, 'counseling_home.html')

@login_required
def resources(request):
    return render(request, 'resources.html')