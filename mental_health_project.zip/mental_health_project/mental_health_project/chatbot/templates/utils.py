import os
import requests
from django.conf import settings

class MentalHealthChatbot:
    def __init__(self):
        # Replace with actual API configuration
        self.api_key = os.getenv('OPENAI_API_KEY')
        self.base_url = 'https://api.openai.com/v1/chat/completions'
    
    def generate_response(self, user_message):
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
        
        # Mental health supportive prompt
        messages = [
            {
                "role": "system", 
                "content": "You are a compassionate mental health support chatbot. Provide empathetic, supportive responses that help users feel heard and understood. Avoid giving medical advice, and suggest professional help when needed."
            },
            {
                "role": "user", 
                "content": user_message
            }
        ]
        
        payload = {
            'model': 'gpt-3.5-turbo',
            'messages': messages,
            'max_tokens': 150
        }
        
        try:
            response = requests.post(self.base_url, headers=headers, json=payload)
            return response.json()['choices'][0]['message']['content']
        except Exception as e:
            return f"I'm experiencing some difficulties. Would you like to try again? Error: {str(e)}"