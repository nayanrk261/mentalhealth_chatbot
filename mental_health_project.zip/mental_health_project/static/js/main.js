// Mental Health Support Website JavaScript

document.addEventListener('DOMContentLoaded', () => {
    // Chatbot Interaction
    const chatbotContainer = document.getElementById('chatbot-container');
    const chatInput = document.getElementById('chat-input');
    const sendButton = document.getElementById('send-message');

    function addMessage(message, type) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', type);
        messageElement.textContent = message;
        chatbotContainer.appendChild(messageElement);
        chatbotContainer.scrollTop = chatbotContainer.scrollHeight;
    }

    async function sendChatMessage() {
        const userMessage = chatInput.value.trim();
        if (!userMessage) return;

        // Add user message
        addMessage(userMessage, 'user-message');
        chatInput.value = '';

        try {
            // Simulate API call (replace with actual API integration)
            const response = await fetch('/chatbot/send', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: userMessage })
            });

            const data = await response.json();
            addMessage(data.response, 'bot-message');
        } catch (error) {
            console.error('Chatbot error:', error);
            addMessage('Sorry, I am experiencing some difficulties.', 'bot-message');
        }
    }

    if (sendButton) {
        sendButton.addEventListener('click', sendChatMessage);
    }

    if (chatInput) {
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendChatMessage();
            }
        });
    }

    // Mood Tracking
    const moodOptions = document.querySelectorAll('.mood-option');
    moodOptions.forEach(option => {
        option.addEventListener('click', () => {
            moodOptions.forEach(opt => opt.classList.remove('selected'));
            option.classList.add('selected');
            
            // Send mood selection to backend
            const moodValue = option.dataset.mood;
            fetch('/track-mood', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ mood: moodValue })
            });
        });
    });

    // Resource Interaction
    const resourceCards = document.querySelectorAll('.resource-card');
    resourceCards.forEach(card => {
        card.addEventListener('click', () => {
            const resourceUrl = card.dataset.url;
            window.open(resourceUrl, '_blank');
        });
    });

    // Smooth Scroll for Navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Simple Form Validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', (e) => {
            const inputs = form.querySelectorAll('input');
            let isValid = true;
            
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('error');
                } else {
                    input.classList.remove('error');
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert('Please fill out all required fields.');
            }
        });
    });
});

// Error Handling Utility
window.addEventListener('error', (event) => {
    console.error('Unhandled error:', event.error);
    // Optionally send error to a logging service
});